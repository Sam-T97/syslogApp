#!/usr/bin/python
import serial, time
from datetime import datetime

ser = serial.Serial()
ser.port = "/dev/ttyUSB0"
ser.baudrate = 9600
ser.bytesize = serial.EIGHTBITS #number of bits per bytes
ser.parity = serial.PARITY_NONE #set parity check: no parity
ser.stopbits = serial.STOPBITS_ONE #number of stop bits
ser.timeout = 1            #non-block read
ser.xonxoff = False     #disable software flow control
ser.rtscts = False     #disable hardware (RTS/CTS) flow control
ser.dsrdtr = False       #disable hardware (DSR/DTR) flow control#ser.port
print (datetime.now())
f = open("/home/pi/Configs/config"+str(datetime.now().date())+".txt","w+")
try:
        ser.open()
except Exception, e:
        print("unable to open port: " + str(e))
        exit()

if ser.isOpen():
        try:
                ser.flushInput()
                ser.flushOutput()
                ser.write("\r".encode())
                time.sleep(3)
                ser.write("terminal length 0 \r")
                time.sleep(0.5)
                ser.flushInput()
                ser.flushOutput()
                ser.write("sh start \r")
                while True:
                        response = ser.readline()
                        f.write(response)
                        if '#' in response:
                                ser.write("exit \r")
                                f.write("\n")
                                ser.close()
                                f.close()
                                exit()
        except Exception, e1:
                print("error: " + str(e1))
else:
        print ("serial port not open")
