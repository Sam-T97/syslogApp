#!/bin/bash

find /home/pi/Configs -mtime +30 -type f -delete