#!/usr/bin/python
import os

path = '/home/pi/Configs' #declare the path to use to collect the config names

text_files = [f for f in os.listdir(path) if f.endswith('.txt')] #get a directory listing of every config present in the directory

for f in text_files:
        text = f
        print(text[6:32])
exit()
