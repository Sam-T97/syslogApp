#!/usr/bin/python3

import serial, time, sys
from pexpect_serial import SerialSpawn

ser = serial.Serial()
ser.port = "/dev/ttyUSB0"
ser.baudrate = 9600
ser.bytesize = serial.EIGHTBITS #number of bits per bytes
ser.parity = serial.PARITY_NONE #set parity check: no parity
ser.stopbits = serial.STOPBITS_ONE #number of stop bits
ser.timeout = 1            #non-block read
ser.xonxoff = False     #disable software flow control
ser.rtscts = False     #disable hardware (RTS/CTS) flow control
ser.dsrdtr = False       #disable hardware (DSR/DTR) flow control#ser.port

ser.open()
ser.flushOutput()
ser.flushInput()

f = open("/home/pi/Configs/config"+sys.argv[1], "r")

for i in range(2):
        f.readline()

ss = SerialSpawn(ser)
ss.sendline('\r')
time.sleep(2)
ss.sendline('en \r')
ss.sendline('conf t \r')

for x in f:
        ss.sendline(x)
        time.sleep(0.5)

ss.close()
exit()