#!/usr/bin/python3
import serial
from pexpect_serial import SerialSpawn

with serial.Serial('/dev/ttyUSB0', 9600, timeout=0) as ser:
        ss = SerialSpawn(ser)
        ss.sendline('\r')
        ss.sendline('en')
        ss.expect('Password:')
        ss.sendline('test')
        ss.close()
        exit()